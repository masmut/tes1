<?php
echo phpversion();
?>